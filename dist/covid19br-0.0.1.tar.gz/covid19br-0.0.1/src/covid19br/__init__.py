from covid19br import download_covid19

__all__ = ['download_covid19']
